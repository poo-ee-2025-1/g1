package planejamento;

import ponto.Ponto;
import robo.RoboVisual;
import matriz.MapaEstoque;

import java.util.*;

public class PlanejadorRota {

    public static List<Ponto> encontrarCaminho(int[][] mapa, Ponto inicio, Ponto fim) {
        int[][] vizinhos = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
        PriorityQueue<Node> fila = new PriorityQueue<>();
        Map<Ponto, Ponto> veioDe = new HashMap<>();
        Map<Ponto, Integer> custoG = new HashMap<>();
        custoG.put(inicio, 0);
        fila.add(new Node(inicio, heuristica(inicio, fim)));

        while (!fila.isEmpty()) {
            Ponto atual = fila.poll().ponto;
            if (atual.equals(fim)) {
                List<Ponto> caminho = new ArrayList<>();
                while (atual != null) {
                    caminho.add(atual);
                    atual = veioDe.get(atual);
                }
                Collections.reverse(caminho);
                return caminho;
            }

            for (int[] dir : vizinhos) {
                int novoX = atual.x + dir[0];
                int novoY = atual.y + dir[1];
                if (novoX < 0 || novoX >= MapaEstoque.getAltura() || novoY < 0 || novoY >= MapaEstoque.getLargura())
                    continue;
                if (mapa[novoX][novoY] == MapaEstoque.OBSTACULO)
                    continue;

                Ponto vizinho = new Ponto(novoX, novoY);
                int novoCusto = custoG.get(atual) + 1;
                if (novoCusto < custoG.getOrDefault(vizinho, Integer.MAX_VALUE)) {
                    custoG.put(vizinho, novoCusto);
                    veioDe.put(vizinho, atual);
                    double fScore = novoCusto + heuristica(vizinho, fim);
                    fila.add(new Node(vizinho, fScore));
                }
            }
        }
        return Collections.emptyList(); // sem caminho
    }

    private static int heuristica(Ponto a, Ponto b) {
        return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
    }

    private static class Node implements Comparable<Node> {
        Ponto ponto;
        double fScore;

        Node(Ponto ponto, double fScore) {
            this.ponto = ponto;
            this.fScore = fScore;
        }

        @Override
        public int compareTo(Node other) {
            return Double.compare(this.fScore, other.fScore);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MapaEstoque mapaEstoque = new MapaEstoque();
        int[][] mapa = mapaEstoque.getMapa();
        Ponto base = new Ponto(0, 0);

        while (true) {
            System.out.println("\n--- Planejador de Rota ---");
            System.out.println("Base: " + base);

            int prateleira = 0;
            while (prateleira < 1 || prateleira > 3) {
                System.out.print("Prateleira (1, 2, 3): ");
                String entrada = scanner.nextLine().trim();
                try {
                    prateleira = Integer.parseInt(entrada);
                    if (prateleira < 1 || prateleira > 3) {
                        System.out.println("Valor inválido. Digite 1, 2 ou 3.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Entrada inválida. Digite um número.");
                }
            }

            int linha = -1;
            while (linha < MapaEstoque.getLinhaInicio() || linha > MapaEstoque.getLinhaFim()) {
                System.out.printf("Linha do item (%d a %d): ", MapaEstoque.getLinhaInicio(), MapaEstoque.getLinhaFim());
                String entradaLinha = scanner.nextLine().trim();
                try {
                    linha = Integer.parseInt(entradaLinha);
                    if (linha < MapaEstoque.getLinhaInicio() || linha > MapaEstoque.getLinhaFim()) {
                        System.out.println("Linha inválida. Digite dentro do intervalo.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Entrada inválida. Digite um número.");
                }
            }

            int[] acessos = MapaEstoque.getPontosAcessoEsqDir(prateleira);
            Ponto acessoEsq = new Ponto(linha, acessos[0]);
            Ponto acessoDir = new Ponto(linha, acessos[1]);

            List<Ponto> rotaEsq = encontrarCaminho(mapa, base, acessoEsq);
            List<Ponto> rotaDir = encontrarCaminho(mapa, base, acessoDir);

            List<Ponto> rotaFinal;
            Ponto alvoFinal;

            if (!rotaEsq.isEmpty() && (rotaDir.isEmpty() || rotaEsq.size() <= rotaDir.size())) {
                rotaFinal = rotaEsq;
                alvoFinal = acessoEsq;
                System.out.println("➡️ Usando acesso ESQUERDO");
            } else if (!rotaDir.isEmpty()) {
                rotaFinal = rotaDir;
                alvoFinal = acessoDir;
                System.out.println("➡️ Usando acesso DIREITO");
            } else {
                System.out.println("⚠️ Nenhum caminho encontrado!");
                continue;
            }

            System.out.println("📍 Caminho encontrado:");
            for (Ponto p : rotaFinal) {
                System.out.print(p + " ");
            }
            System.out.println();

            // ✅ Simulação GRÁFICA com JavaFX
            RoboVisual.iniciarSimulacao(rotaFinal, mapaEstoque);

            break; // Apenas 1 simulação por vez com JavaFX (não dá para abrir outra janela depois)
        }

        scanner.close();
        System.out.println("Programa encerrado.");
    }
}


