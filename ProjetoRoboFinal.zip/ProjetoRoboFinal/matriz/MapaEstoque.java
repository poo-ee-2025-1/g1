package matriz;

import java.util.Arrays;

public class MapaEstoque {
    public static final int ALTURA_MAPA = 21;
    public static final int LARGURA_MAPA = 19;
    public static final int CAMINHO_LIVRE = 0;
    public static final int OBSTACULO = 1;

    private static final int[] PRATELEIRA_1_COLS = {3, 4, 5};
    private static final int[] PRATELEIRA_2_COLS = {8, 9, 10};
    private static final int[] PRATELEIRA_3_COLS = {13, 14, 15};
    private static final int LINHA_INICIO = 1;
    private static final int LINHA_FIM = 18;

    private int[][] mapa;

    public MapaEstoque() {
        mapa = new int[ALTURA_MAPA][LARGURA_MAPA];
        for (int[] linha : mapa) Arrays.fill(linha, CAMINHO_LIVRE);

        for (int i = LINHA_INICIO; i <= LINHA_FIM; i++) {
            for (int j : PRATELEIRA_1_COLS) mapa[i][j] = OBSTACULO;
            for (int j : PRATELEIRA_2_COLS) mapa[i][j] = OBSTACULO;
            for (int j : PRATELEIRA_3_COLS) mapa[i][j] = OBSTACULO;
        }
    }

    public int[][] getMapa() {
        return mapa;
    }

    public boolean ehLivre(int x, int y) {
        return mapa[x][y] == CAMINHO_LIVRE;
    }

    public static int getAltura() {
        return ALTURA_MAPA;
    }

    public static int getLargura() {
        return LARGURA_MAPA;
    }

    public static int getLinhaInicio() {
        return LINHA_INICIO;
    }

    public static int getLinhaFim() {
        return LINHA_FIM;
    }

    public static int[] getPrateleiraCols(int num) {
        if (num == 1) return new int[]{3, 4, 5};
        if (num == 2) return new int[]{8, 9, 10};
        return new int[]{13, 14, 15};
    }

    public static int[] getPontosAcessoEsqDir(int num) {
        if (num == 1) return new int[]{2, 6};
        if (num == 2) return new int[]{7, 11};
        return new int[]{12, 16};
    }
    
    public void imprimirMapa() {
    for (int i = 0; i < ALTURA_MAPA; i++) {
        for (int j = 0; j < LARGURA_MAPA; j++) {
            System.out.print(mapa[i][j] == OBSTACULO ? "#" : ".");
        }
        System.out.println();
    }
}

}

