package robo;

import ponto.Ponto;
import java.util.List;


public class Robo {
    private Ponto posicaoAtual;

    public Robo(int xInicial, int yInicial) {
        this.posicaoAtual = new Ponto(xInicial, yInicial);
        System.out.println("Robô inicializado na posição: " + posicaoAtual);
    }

    public void moverParaCima() {
        posicaoAtual.x--;
        exibirPosicao();
    }

    public void moverParaBaixo() {
        posicaoAtual.x++;
        exibirPosicao();
    }

    public void moverParaEsquerda() {
        posicaoAtual.y--;
        exibirPosicao();
    }

    public void moverParaDireita() {
        posicaoAtual.y++;
        exibirPosicao();
    }

    public void seguirCaminho(List<Ponto> rota) {
        System.out.println("Iniciando movimentação do robô pelo caminho...");
        for (Ponto destino : rota) {
            System.out.println("Indo até " + destino);
            while (posicaoAtual.x < destino.x) moverParaBaixo();
            while (posicaoAtual.x > destino.x) moverParaCima();
            while (posicaoAtual.y < destino.y) moverParaDireita();
            while (posicaoAtual.y > destino.y) moverParaEsquerda();
        }
        System.out.println("Robô chegou ao destino!");
    }

    private void exibirPosicao() {
        System.out.println("Robô na posição: " + posicaoAtual);
        try {
        Thread.sleep(200);
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
    }
    }
}
