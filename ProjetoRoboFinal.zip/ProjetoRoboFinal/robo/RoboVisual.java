package robo;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import ponto.Ponto;
import matriz.MapaEstoque;

import java.util.List;

public class RoboVisual extends Application {

    private static final int TAM_CELULA = 30;
    private static List<Ponto> rota;
    private static MapaEstoque mapaEstoque;
    private static Ponto posicaoAtual;

    private GridPane grid = new GridPane();

    public static void iniciarSimulacao(List<Ponto> rotaCalculada, MapaEstoque mapa) {
        rota = rotaCalculada;
        mapaEstoque = mapa;
        Application.launch(); // Inicia a aplicação JavaFX
    }

    @Override
    public void start(Stage primaryStage) {
        if (rota == null || mapaEstoque == null) {
            System.err.println("Erro: Rota ou mapa não foram inicializados.");
            Platform.exit();
            return;
        }

        posicaoAtual = new Ponto(0, 0);

        desenharGrid();

        int largura = MapaEstoque.getLargura() * TAM_CELULA;
        int altura = MapaEstoque.getAltura() * TAM_CELULA;

        Scene scene = new Scene(grid, largura, altura);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Simulador Visual do Robô");
        primaryStage.show();

        new Thread(() -> {
            try {
                seguirCaminho(rota);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void desenharGrid() {
        Platform.runLater(() -> {
            grid.getChildren().clear();
            int[][] mapa = mapaEstoque.getMapa();

            for (int i = 0; i < MapaEstoque.getAltura(); i++) {
                for (int j = 0; j < MapaEstoque.getLargura(); j++) {
                    Rectangle cell = new Rectangle(TAM_CELULA, TAM_CELULA);

                    if (mapa[i][j] == MapaEstoque.OBSTACULO) {
                        cell.setFill(Color.BLACK);
                    } else if (posicaoAtual.x == i && posicaoAtual.y == j) {
                        cell.setFill(Color.RED); // posição atual do robô
                    } else {
                        cell.setFill(Color.LIGHTGRAY);
                    }

                    cell.setStroke(Color.GRAY);
                    grid.add(cell, j, i);
                }
            }
        });
    }

    private void seguirCaminho(List<Ponto> rota) throws InterruptedException {
        for (Ponto destino : rota) {
            while (posicaoAtual.x < destino.x) {
                posicaoAtual.x++;
                atualizarUI();
            }
            while (posicaoAtual.x > destino.x) {
                posicaoAtual.x--;
                atualizarUI();
            }
            while (posicaoAtual.y < destino.y) {
                posicaoAtual.y++;
                atualizarUI();
            }
            while (posicaoAtual.y > destino.y) {
                posicaoAtual.y--;
                atualizarUI();
            }
        }
        System.out.println("✅ Robô chegou ao destino!");
    }

    private void atualizarUI() throws InterruptedException {
        desenharGrid();
        Thread.sleep(300); // Delay visual
    }
}

