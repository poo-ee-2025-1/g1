
# Relatório de Produção Individual – Samuel Vieira

## 1. Atribuição de cargo e tarefas
- Cargo: Pessoa 2 – Movimento do robô
- Atribuições: Implementar a classe `Robo`, simular movimentação na matriz com atualização em tempo real.

## 2. Contribuições principais
- Implementação da classe `Robo` com métodos de movimentação.
- Integração com matriz 2D do `Roboestoquista`.
- Simulação visual do trajeto do robô.
- Commit principal: simulacao-matriz-robo
- Dificuldade: Ajustar delay e visualização no console para funcionar em BlueJ.

## 3. Contribuição além do atribuído
- Auxiliei na conversão da rota de A* para uso com o robô.
- Testei em diferentes IDEs (VS Code, BlueJ).

## 4. Considerações gerais
- Aprendi a manipular matrizes e usar delays para simulação.
- Pendência: integrar sensores e decisões do controlador.
- Conclusão: etapa muito importante para consolidar conceitos de orientação a objetos.
