
# Projeto Robô Estoquista

## Seção 1 – Introdução
Este projeto simula um robô estoquista capaz de se mover por um mapa 2D com obstáculos (prateleiras) e buscar itens em locais definidos. O objetivo é aplicar conceitos de Programação Orientada a Objetos em Java com visualização no console.

## Seção 2 – Plano
### Objetivo Geral
Desenvolver um sistema Java que simula a movimentação de um robô em um supermercado representado por uma matriz.

### Objetivos Específicos
- Criar uma matriz que represente o ambiente de um supermercado;
- Implementar a movimentação do robô com base em uma rota simulada;
- Exibir a movimentação em tempo real no console;
- Aplicar princípios de orientação a objetos (encapsulamento, herança, etc).
