
# Seção 3 – Divisão de Tarefas

| Tarefa | Responsável | Descrição | Prazo |
|--------|-------------|-----------|-------|
| Implementar classe Robo | Samuel | Criar lógica de movimentação em matriz | 05/07 |
| Gerar rota simulada | Samuel | Criar rota com lista de coordenadas | 05/07 |
| Integrar visualização no console | Samuel | Atualizar posição do robô passo a passo | 05/07 |
